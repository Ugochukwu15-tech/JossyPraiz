import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, MessageCircle, Star, Heart } from 'lucide-react';
import { Product } from '../types';
import { formatPrice } from '../lib/utils';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { motion } from 'motion/react';
import { WHATSAPP_LINK } from '../constants';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const isWishlisted = isInWishlist(product.id);

  const handleWhatsAppOrder = (e: React.MouseEvent) => {
    e.preventDefault();
    const message = `Hello JossyPraiz, I want to order: ${product.name} (${formatPrice(product.price)})`;
    window.open(`${WHATSAPP_LINK}?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="group bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100 transition-all hover:shadow-md"
    >
      <div className="relative aspect-[3/4] overflow-hidden">
        <Link to={`/product/${product.id}`} className="block h-full w-full">
          <img 
            src={product.image} 
            alt={product.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
        </Link>
        
        {/* Wishlist Toggle */}
        <button 
          onClick={(e) => {
            e.preventDefault();
            toggleWishlist(product);
          }}
          className={`absolute top-2 right-2 p-2 rounded-full shadow-md transition-all z-10 ${isWishlisted ? 'bg-gold text-white' : 'bg-white text-gray-400 hover:text-gold'}`}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>

        {product.isBestSeller && (
          <span className="absolute top-2 left-2 bg-gold text-white text-[10px] font-bold px-2 py-1 rounded uppercase">
            Best Seller
          </span>
        )}
        {product.isNewArrival && (
          <span className="absolute top-2 left-2 bg-dark text-white text-[10px] font-bold px-2 py-1 rounded uppercase">
            New Arrival
          </span>
        )}
      </div>

      <div className="p-4">
        <div className="flex items-center space-x-1 mb-1">
          {[...Array(5)].map((_, i) => (
            <Star 
              key={i} 
              className={`w-3 h-3 ${i < Math.floor(product.averageRating || 0) ? 'fill-gold text-gold' : 'text-gray-200'}`} 
            />
          ))}
          <span className="text-[10px] text-gray-400 ml-1">({product.reviewCount || 0})</span>
        </div>
        
        <Link to={`/product/${product.id}`}>
          <h3 className="font-bold text-dark mb-1 group-hover:text-gold transition-colors line-clamp-1">
            {product.name}
          </h3>
        </Link>
        
        <p className="text-sm text-gray-500 mb-3">{product.fabricType}</p>
        
        <div className="flex items-center justify-between mb-4">
          <span className="text-lg font-bold text-dark">{formatPrice(product.price)}</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button 
            onClick={() => addToCart(product)}
            className="flex items-center justify-center space-x-2 bg-dark text-white py-2 rounded text-xs font-bold hover:bg-opacity-90 transition-all"
          >
            <ShoppingCart className="w-3 h-3" />
            <span>Add</span>
          </button>
          <button 
            onClick={handleWhatsAppOrder}
            className="flex items-center justify-center space-x-2 bg-[#25D366] text-white py-2 rounded text-xs font-bold hover:bg-opacity-90 transition-all"
          >
            <MessageCircle className="w-3 h-3" />
            <span>Order</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;
