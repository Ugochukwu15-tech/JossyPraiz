import React, { useState, useEffect } from 'react';
import { Star, User, Calendar, Send, LogIn } from 'lucide-react';
import { Review } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { 
  db, 
  auth, 
  googleProvider, 
  signInWithPopup, 
  collection, 
  addDoc, 
  handleFirestoreError, 
  OperationType 
} from '../firebase';
import { useProductReviews } from '../hooks/useProductReviews';

interface ReviewSystemProps {
  productId: string;
}

const ReviewSystem: React.FC<ReviewSystemProps> = ({ productId }) => {
  const { reviews, averageRating, reviewCount, loading } = useProductReviews(productId);
  const [newReview, setNewReview] = useState({
    userName: '',
    rating: 5,
    comment: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [user, setUser] = useState(auth.currentUser);

  const [sortBy, setSortBy] = useState<'newest' | 'highest' | 'lowest'>('newest');
  const [filterRating, setFilterRating] = useState<number | null>(null);

  // Listen for auth changes
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setUser(user);
      if (user) {
        setNewReview(prev => ({ ...prev, userName: user.displayName || '' }));
      }
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.userName || !newReview.comment) return;
    if (!user) {
      handleLogin();
      return;
    }

    setIsSubmitting(true);

    const path = 'reviews';
    try {
      const reviewData = {
        productId,
        userName: newReview.userName,
        rating: newReview.rating,
        comment: newReview.comment,
        createdAt: new Date().toISOString(),
        userId: user.uid
      };

      await addDoc(collection(db, path), reviewData);
      
      setNewReview({ userName: user.displayName || '', rating: 5, comment: '' });
      setIsSubmitting(false);
      setShowForm(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gold"></div>
      </div>
    );
  }

  const filteredReviews = reviews
    .filter(r => !filterRating || r.rating === filterRating)
    .sort((a, b) => {
      if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sortBy === 'highest') return b.rating - a.rating;
      if (sortBy === 'lowest') return a.rating - b.rating;
      return 0;
    });

  const ratingCounts = [5, 4, 3, 2, 1].map(star => ({
    star,
    count: reviews.filter(r => r.rating === star).length
  }));

  return (
    <div className="space-y-12">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-1 space-y-6">
          <h3 className="text-2xl font-bold">Customer Reviews</h3>
          <div className="flex items-center space-x-4">
            <div className="text-5xl font-bold text-dark">{averageRating.toFixed(1)}</div>
            <div>
              <div className="flex items-center space-x-1 mb-1">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`w-4 h-4 ${i < Math.round(averageRating) ? 'fill-gold text-gold' : 'text-gray-200'}`} 
                  />
                ))}
              </div>
              <p className="text-sm text-gray-500">Based on {reviewCount} reviews</p>
            </div>
          </div>

          <div className="space-y-3">
            {ratingCounts.map(({ star, count }) => (
              <button 
                key={star}
                onClick={() => setFilterRating(filterRating === star ? null : star)}
                className={`w-full flex items-center space-x-4 group ${filterRating === star ? 'opacity-100' : 'opacity-60 hover:opacity-100'} transition-opacity`}
              >
                <div className="flex items-center space-x-1 w-12">
                  <span className="text-sm font-bold">{star}</span>
                  <Star className="w-3 h-3 fill-gold text-gold" />
                </div>
                <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${(count / (reviewCount || 1)) * 100}%` }}
                    className="h-full bg-gold"
                  />
                </div>
                <div className="w-8 text-right text-xs text-gray-400">{count}</div>
              </button>
            ))}
          </div>

          <div className="space-y-4">
            {user ? (
              <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl border border-gray-100">
                <div className="w-10 h-10 rounded-full bg-gold/10 flex items-center justify-center text-gold overflow-hidden">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt={user.displayName || ''} className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-5 h-5" />
                  )}
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-bold">{user.displayName}</p>
                    <button 
                      onClick={() => auth.signOut()}
                      className="text-[10px] text-red-500 hover:underline font-bold"
                    >
                      Logout
                    </button>
                  </div>
                  <p className="text-xs text-gray-500">{user.email}</p>
                </div>
              </div>
            ) : (
              <button 
                onClick={handleLogin}
                className="w-full flex items-center justify-center space-x-2 p-4 bg-white border-2 border-gold text-gold rounded-xl font-bold hover:bg-gold hover:text-white transition-all"
              >
                <LogIn className="w-5 h-5" />
                <span>Login to Review</span>
              </button>
            )}

            <button 
              onClick={() => setShowForm(!showForm)}
              className="btn-primary w-full py-4"
            >
              {showForm ? 'Cancel Review' : 'Write a Review'}
            </button>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-8">
          <div className="flex items-center justify-between border-b border-gray-100 pb-4">
            <div className="text-sm text-gray-500">
              Showing <span className="font-bold text-dark">{filteredReviews.length}</span> reviews
              {filterRating && <span> with {filterRating} stars</span>}
            </div>
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="text-sm font-bold bg-transparent border-none focus:ring-0 cursor-pointer"
            >
              <option value="newest">Newest First</option>
              <option value="highest">Highest Rating</option>
              <option value="lowest">Lowest Rating</option>
            </select>
          </div>

          <AnimatePresence>
            {showForm && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <form onSubmit={handleSubmit} className="bg-gray-50 p-8 rounded-2xl space-y-6 border border-gray-100">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold mb-2">Your Name</label>
                      <input 
                        type="text" 
                        required
                        value={newReview.userName}
                        onChange={(e) => setNewReview({ ...newReview, userName: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-gold transition-colors"
                        placeholder="Enter your name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold mb-2">Rating</label>
                      <div className="flex items-center space-x-2 h-[50px]">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setNewReview({ ...newReview, rating: star })}
                            className="focus:outline-none transition-transform hover:scale-110"
                          >
                            <Star 
                              className={`w-8 h-8 ${star <= newReview.rating ? 'fill-gold text-gold' : 'text-gray-300'}`} 
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-bold mb-2">Your Review</label>
                    <textarea 
                      required
                      rows={4}
                      value={newReview.comment}
                      onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-gold transition-colors resize-none"
                      placeholder="Share your thoughts about this fabric..."
                    />
                  </div>

                  <button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="btn-primary w-full flex items-center justify-center space-x-2 py-4"
                  >
                    {isSubmitting ? (
                      <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <Send className="w-5 h-5" />
                        <span>Submit Review</span>
                      </>
                    )}
                  </button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="space-y-8">
            {filteredReviews.length > 0 ? (
              filteredReviews.map((review) => (
                <motion.div 
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={review.id} 
                  className="border-b border-gray-100 pb-8 last:border-0"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-full bg-gold/10 flex items-center justify-center text-gold">
                        <User className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-dark">{review.userName}</h4>
                        <div className="flex items-center space-x-2 text-xs text-gray-400">
                          <Calendar className="w-3 h-3" />
                          <span>{new Date(review.createdAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`w-4 h-4 ${i < review.rating ? 'fill-gold text-gold' : 'text-gray-200'}`} 
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-600 leading-relaxed italic">"{review.comment}"</p>
                </motion.div>
              ))
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                <p className="text-gray-500">No reviews yet. Be the first to review this product!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReviewSystem;
