import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from 'lucide-react';
import { CONTACT_EMAIL, CONTACT_PHONE } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-dark text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
        {/* Brand */}
        <div>
          <Link to="/" className="text-2xl font-serif font-bold mb-4 block">
            Jossy<span className="text-gold">Praiz</span>
          </Link>
          <p className="text-gray-400 text-sm leading-relaxed mb-6">
            Quality Fabrics for Every Style. We provide premium textiles for fashion designers, boutique owners, and individuals across Nigeria.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="hover:text-gold transition-colors"><Instagram className="w-5 h-5" /></a>
            <a href="#" className="hover:text-gold transition-colors"><Facebook className="w-5 h-5" /></a>
            <a href="#" className="hover:text-gold transition-colors"><Twitter className="w-5 h-5" /></a>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-lg font-bold mb-6 text-gold">Quick Links</h4>
          <ul className="space-y-4 text-sm text-gray-400">
            <li><Link to="/shop" className="hover:text-white transition-colors">Shop All Fabrics</Link></li>
            <li><Link to="/categories" className="hover:text-white transition-colors">Categories</Link></li>
            <li><Link to="/about" className="hover:text-white transition-colors">Our Story</Link></li>
            <li><Link to="/testimonials" className="hover:text-white transition-colors">Customer Reviews</Link></li>
            <li><Link to="/faq" className="hover:text-white transition-colors">FAQs</Link></li>
          </ul>
        </div>

        {/* Categories */}
        <div>
          <h4 className="text-lg font-bold mb-6 text-gold">Categories</h4>
          <ul className="space-y-4 text-sm text-gray-400">
            <li><Link to="/shop?category=senator" className="hover:text-white transition-colors">Senator Materials</Link></li>
            <li><Link to="/shop?category=ankara" className="hover:text-white transition-colors">Ankara Prints</Link></li>
            <li><Link to="/shop?category=lace" className="hover:text-white transition-colors">Premium Lace</Link></li>
            <li><Link to="/shop?category=shirt" className="hover:text-white transition-colors">Shirt Fabrics</Link></li>
            <li><Link to="/shop?category=hijab" className="hover:text-white transition-colors">Hijab Materials</Link></li>
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="text-lg font-bold mb-6 text-gold">Contact Us</h4>
          <ul className="space-y-4 text-sm text-gray-400">
            <li className="flex items-start space-x-3">
              <MapPin className="w-5 h-5 text-gold shrink-0" />
              <span>123 Textile Plaza, Lagos Island, Lagos, Nigeria</span>
            </li>
            <li className="flex items-center space-x-3">
              <Phone className="w-5 h-5 text-gold shrink-0" />
              <span>{CONTACT_PHONE}</span>
            </li>
            <li className="flex items-center space-x-3">
              <Mail className="w-5 h-5 text-gold shrink-0" />
              <span>{CONTACT_EMAIL}</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 mt-16 pt-8 border-t border-gray-800 text-center text-gray-500 text-xs">
        <p>&copy; {new Date().getFullYear()} JossyPraiz Textile. All Rights Reserved. Designed for Quality.</p>
      </div>
    </footer>
  );
};

export default Footer;
