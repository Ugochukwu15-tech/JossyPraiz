import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingBag, Menu, X, Phone, Search, Heart } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { motion, AnimatePresence } from 'motion/react';
import { WHATSAPP_LINK } from '../constants';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { totalItems } = useCart();
  const { totalWishlistItems } = useWishlist();
  const navigate = useNavigate();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Shop', path: '/shop' },
    { name: 'Categories', path: '/categories' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="bg-dark text-white py-2 px-4 text-center text-xs md:text-sm font-medium">
        Nationwide Delivery Across Nigeria | Quality Guaranteed
      </div>
      
      <nav className="max-w-7xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between">
        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden p-2"
          onClick={() => setIsMenuOpen(true)}
        >
          <Menu className="w-6 h-6" />
        </button>

        {/* Logo */}
        <Link to="/" className="flex flex-col items-center md:items-start">
          <span className="text-2xl font-serif font-bold text-dark leading-tight">
            Jossy<span className="text-gold">Praiz</span>
          </span>
          <span className="text-[10px] uppercase tracking-widest text-gray-500 font-bold">Textile</span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-8">
          {navLinks.map(link => (
            <Link 
              key={link.path} 
              to={link.path}
              className="text-sm font-semibold text-dark hover:text-gold transition-colors"
            >
              {link.name}
            </Link>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-4">
          <button className="hidden sm:block p-2 hover:text-gold transition-colors">
            <Search className="w-5 h-5" />
          </button>
          <Link to="/wishlist" className="relative p-2 hover:text-gold transition-colors">
            <Heart className="w-6 h-6" />
            {totalWishlistItems > 0 && (
              <span className="absolute top-0 right-0 bg-gold text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                {totalWishlistItems}
              </span>
            )}
          </Link>
          <Link to="/cart" className="relative p-2 hover:text-gold transition-colors">
            <ShoppingBag className="w-6 h-6" />
            {totalItems > 0 && (
              <span className="absolute top-0 right-0 bg-gold text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                {totalItems}
              </span>
            )}
          </Link>
          <a 
            href={WHATSAPP_LINK} 
            target="_blank" 
            rel="noopener noreferrer"
            className="hidden lg:flex items-center space-x-2 bg-gold text-white px-4 py-2 rounded-md text-sm font-bold hover:bg-opacity-90"
          >
            <Phone className="w-4 h-4" />
            <span>Order via WhatsApp</span>
          </a>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              className="fixed inset-0 bg-black/50 z-[60]"
            />
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 w-4/5 max-w-sm bg-white z-[70] p-6 shadow-xl"
            >
              <div className="flex items-center justify-between mb-8">
                <span className="text-xl font-serif font-bold">Jossy<span className="text-gold">Praiz</span></span>
                <button onClick={() => setIsMenuOpen(false)}>
                  <X className="w-6 h-6" />
                </button>
              </div>
              <div className="flex flex-col space-y-6">
                {navLinks.map(link => (
                  <Link 
                    key={link.path} 
                    to={link.path}
                    onClick={() => setIsMenuOpen(false)}
                    className="text-lg font-bold text-dark border-b border-gray-100 pb-2"
                  >
                    {link.name}
                  </Link>
                ))}
                <a 
                  href={WHATSAPP_LINK}
                  className="flex items-center justify-center space-x-2 bg-gold text-white py-4 rounded-md font-bold"
                >
                  <Phone className="w-5 h-5" />
                  <span>Order via WhatsApp</span>
                </a>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;
