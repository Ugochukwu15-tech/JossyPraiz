export const WHATSAPP_NUMBER = '96891694398';
export const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER}`;
export const CONTACT_EMAIL = 'info@jossypraiztextile.com';
export const CONTACT_PHONE = '+968 9169 4398';
