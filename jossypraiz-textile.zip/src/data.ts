import { Product, Category, Testimonial } from './types';

export const CATEGORIES: Category[] = [
  {
    id: 'senator',
    name: 'Senator Materials',
    image: 'https://picsum.photos/seed/senator/600/800',
    description: 'Premium plain and pattern materials for the modern man.'
  },
  {
    id: 'ankara',
    name: 'Ankara & Native',
    image: 'https://picsum.photos/seed/ankara/600/800',
    description: 'Vibrant African prints for every occasion.'
  },
  {
    id: 'shirt',
    name: 'Shirt Fabrics',
    image: 'https://picsum.photos/seed/shirt/600/800',
    description: 'High-quality cotton and linen for corporate and casual shirts.'
  },
  {
    id: 'tshirt',
    name: 'T-Shirt Materials',
    image: 'https://picsum.photos/seed/tshirt/600/800',
    description: 'Soft, breathable jersey fabrics for comfortable tees.'
  },
  {
    id: 'lace',
    name: 'Lace & Premium',
    image: 'https://picsum.photos/seed/lace/600/800',
    description: 'Exquisite lace materials for weddings and luxury events.'
  },
  {
    id: 'hijab',
    name: 'Hijab Materials',
    image: 'https://picsum.photos/seed/hijab/600/800',
    description: 'Elegant and modest fabrics for stylish hijabs.'
  }
];

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Premium Cashmere Senator',
    price: 15000,
    category: 'senator',
    image: 'https://picsum.photos/seed/fabric1/600/800',
    images: ['https://picsum.photos/seed/fabric1/600/800', 'https://picsum.photos/seed/fabric1b/600/800'],
    description: 'Soft, durable, and wrinkle-resistant cashmere material perfect for Senator styles.',
    fabricType: 'Cashmere',
    isBestSeller: true,
    colors: ['Navy Blue', 'Charcoal Grey', 'Wine'],
    averageRating: 4.8,
    reviewCount: 24
  },
  {
    id: '2',
    name: 'Vibrant Wax Ankara',
    price: 8500,
    category: 'ankara',
    image: 'https://picsum.photos/seed/fabric2/600/800',
    images: ['https://picsum.photos/seed/fabric2/600/800'],
    description: '100% Cotton high-quality wax print with vibrant colors that do not fade.',
    fabricType: 'Cotton Wax',
    isNewArrival: true,
    colors: ['Multi-color Pattern'],
    averageRating: 4.5,
    reviewCount: 15
  },
  {
    id: '3',
    name: 'Egyptian Cotton Shirting',
    price: 12000,
    category: 'shirt',
    image: 'https://picsum.photos/seed/fabric3/600/800',
    images: ['https://picsum.photos/seed/fabric3/600/800'],
    description: 'Breathable and luxurious Egyptian cotton for high-end corporate shirts.',
    fabricType: 'Egyptian Cotton',
    isSpecialOffer: true,
    colors: ['Sky Blue', 'White', 'Pink'],
    averageRating: 4.9,
    reviewCount: 32
  },
  {
    id: '4',
    name: 'Heavy Crepe Hijab Fabric',
    price: 5000,
    category: 'hijab',
    image: 'https://picsum.photos/seed/fabric4/600/800',
    images: ['https://picsum.photos/seed/fabric4/600/800'],
    description: 'Non-slip, opaque, and elegant heavy crepe material for beautiful hijabs.',
    fabricType: 'Heavy Crepe',
    colors: ['Emerald Green', 'Black', 'Nude'],
    averageRating: 4.2,
    reviewCount: 8
  },
  {
    id: '5',
    name: 'Swiss Voile Lace',
    price: 45000,
    category: 'lace',
    image: 'https://picsum.photos/seed/fabric5/600/800',
    images: ['https://picsum.photos/seed/fabric5/600/800'],
    description: 'Intricately designed Swiss voile lace for premium traditional outfits.',
    fabricType: 'Swiss Voile',
    isBestSeller: true,
    colors: ['Gold', 'White', 'Silver'],
    averageRating: 5.0,
    reviewCount: 12
  },
  {
    id: '6',
    name: 'Premium Jersey Knit',
    price: 4500,
    category: 'tshirt',
    image: 'https://picsum.photos/seed/fabric6/600/800',
    images: ['https://picsum.photos/seed/fabric6/600/800'],
    description: 'High-stretch, soft jersey knit for comfortable T-shirts and casual wear.',
    fabricType: 'Cotton Jersey',
    colors: ['Black', 'White', 'Red'],
    averageRating: 4.0,
    reviewCount: 5
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Olawale Johnson',
    role: 'Fashion Designer',
    content: 'JossyPraiz has the best Senator materials in Lagos. The quality is consistent and my clients love the finish.',
    rating: 5
  },
  {
    id: '2',
    name: 'Amaka Eze',
    role: 'Boutique Owner',
    content: 'I get all my Ankara stock from here. Fast delivery and the patterns are always trending.',
    rating: 5
  },
  {
    id: '3',
    name: 'Fatima Yusuf',
    role: 'Individual Buyer',
    content: 'The Hijab materials are so soft and easy to style. Highly recommended!',
    rating: 4
  }
];
