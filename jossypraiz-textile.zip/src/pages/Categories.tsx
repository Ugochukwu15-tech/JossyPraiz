import React from 'react';
import { Link } from 'react-router-dom';
import { CATEGORIES } from '../data';
import { ArrowRight } from 'lucide-react';

const Categories: React.FC = () => {
  return (
    <div className="section-padding min-h-screen">
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl mb-4">Shop By Category</h1>
        <p className="text-gray-500 max-w-2xl mx-auto">Explore our diverse collection of premium fabrics, from traditional Ankara to modern Senator materials.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {CATEGORIES.map(category => (
          <Link 
            key={category.id} 
            to={`/shop?category=${category.id}`}
            className="group block bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 transition-all hover:shadow-xl"
          >
            <div className="aspect-[16/9] overflow-hidden">
              <img 
                src={category.image} 
                alt={category.name} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="p-8">
              <h3 className="text-2xl font-serif mb-3 group-hover:text-gold transition-colors">{category.name}</h3>
              <p className="text-gray-500 mb-6 line-clamp-2">{category.description}</p>
              <div className="flex items-center space-x-2 text-gold font-bold">
                <span>View Collection</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default Categories;
