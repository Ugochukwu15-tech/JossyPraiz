import React from 'react';
import { Mail, Phone, MapPin, MessageCircle, Clock } from 'lucide-react';
import { WHATSAPP_LINK, CONTACT_EMAIL, CONTACT_PHONE } from '../constants';

const Contact: React.FC = () => {
  return (
    <div className="section-padding min-h-screen">
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl mb-4">Get In Touch</h1>
        <p className="text-gray-500 max-w-2xl mx-auto">Have a question or want to place a bulk order? We'd love to hear from you.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Contact Info */}
        <div className="lg:col-span-1 space-y-8">
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="text-xl font-bold mb-8">Contact Information</h3>
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="bg-gold/10 p-3 rounded-lg"><Phone className="w-5 h-5 text-gold" /></div>
                <div>
                  <p className="text-xs uppercase font-bold text-gray-400 mb-1">Call Us</p>
                  <p className="font-bold text-dark">{CONTACT_PHONE}</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="bg-gold/10 p-3 rounded-lg"><Mail className="w-5 h-5 text-gold" /></div>
                <div>
                  <p className="text-xs uppercase font-bold text-gray-400 mb-1">Email Us</p>
                  <p className="font-bold text-dark">{CONTACT_EMAIL}</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="bg-gold/10 p-3 rounded-lg"><MapPin className="w-5 h-5 text-gold" /></div>
                <div>
                  <p className="text-xs uppercase font-bold text-gray-400 mb-1">Visit Us</p>
                  <p className="font-bold text-dark">123 Textile Plaza, Lagos Island, Lagos</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="bg-gold/10 p-3 rounded-lg"><Clock className="w-5 h-5 text-gold" /></div>
                <div>
                  <p className="text-xs uppercase font-bold text-gray-400 mb-1">Business Hours</p>
                  <p className="font-bold text-dark">Mon - Sat: 8am - 6pm</p>
                </div>
              </div>
            </div>
          </div>

          <a 
            href={WHATSAPP_LINK}
            className="flex items-center justify-center space-x-3 bg-[#25D366] text-white p-6 rounded-2xl font-bold text-lg hover:bg-opacity-90 transition-all shadow-lg shadow-green-500/20"
          >
            <MessageCircle className="w-6 h-6" />
            <span>Chat on WhatsApp</span>
          </a>
        </div>

        {/* Contact Form */}
        <div className="lg:col-span-2">
          <div className="bg-white p-8 md:p-12 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="text-2xl font-bold mb-8">Send Us a Message</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-600">Full Name</label>
                  <input 
                    type="text" 
                    placeholder="John Doe"
                    className="w-full border border-gray-200 rounded-lg py-3 px-4 focus:outline-none focus:border-gold"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-600">Phone Number</label>
                  <input 
                    type="tel" 
                    placeholder="+234..."
                    className="w-full border border-gray-200 rounded-lg py-3 px-4 focus:outline-none focus:border-gold"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-600">Email Address</label>
                <input 
                  type="email" 
                  placeholder="john@example.com"
                  className="w-full border border-gray-200 rounded-lg py-3 px-4 focus:outline-none focus:border-gold"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-600">Subject</label>
                <select className="w-full border border-gray-200 rounded-lg py-3 px-4 focus:outline-none focus:border-gold bg-white">
                  <option>General Inquiry</option>
                  <option>Bulk/Wholesale Order</option>
                  <option>Order Status</option>
                  <option>Feedback</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-600">Your Message</label>
                <textarea 
                  rows={5}
                  placeholder="How can we help you?"
                  className="w-full border border-gray-200 rounded-lg py-3 px-4 focus:outline-none focus:border-gold"
                ></textarea>
              </div>
              <button type="submit" className="btn-primary w-full text-lg">
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
