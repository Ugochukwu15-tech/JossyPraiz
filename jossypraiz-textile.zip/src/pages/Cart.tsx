import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight, MessageCircle, ShieldCheck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { formatPrice } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { WHATSAPP_LINK } from '../constants';

const Cart: React.FC = () => {
  const { cart, removeFromCart, updateQuantity, totalPrice, totalItems, clearCart } = useCart();
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    city: '',
    state: ''
  });

  const handleWhatsAppCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    const itemsList = cart.map(item => `- ${item.name} (${item.quantity}x) - ${formatPrice(item.price * item.quantity)}`).join('\n');
    const message = `Hello JossyPraiz, I want to place an order:\n\n*Customer Details:*\nName: ${formData.name}\nPhone: ${formData.phone}\nAddress: ${formData.address}, ${formData.city}, ${formData.state}\n\n*Order Summary:*\n${itemsList}\n\n*Total: ${formatPrice(totalPrice)}*`;
    window.open(`${WHATSAPP_LINK}?text=${encodeURIComponent(message)}`, '_blank');
  };

  if (cart.length === 0) {
    return (
      <div className="section-padding min-h-[60vh] flex flex-col items-center justify-center text-center">
        <div className="bg-gray-100 p-8 rounded-full mb-6">
          <ShoppingBag className="w-16 h-16 text-gray-300" />
        </div>
        <h2 className="text-3xl mb-4">Your cart is empty</h2>
        <p className="text-gray-500 mb-8 max-w-md">Looks like you haven't added any fabrics to your cart yet. Browse our collection to find your style.</p>
        <Link to="/shop" className="btn-primary flex items-center space-x-2">
          <span>Start Shopping</span>
          <ArrowRight className="w-5 h-5" />
        </Link>
      </div>
    );
  }

  return (
    <div className="section-padding min-h-screen">
      <h1 className="text-4xl md:text-5xl mb-12">Your Shopping Cart</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-6">
          <AnimatePresence>
            {cart.map(item => (
              <motion.div 
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="flex items-center space-x-4 bg-white p-4 rounded-2xl border border-gray-100 shadow-sm"
              >
                <div className="w-24 h-32 rounded-lg overflow-hidden shrink-0">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg mb-1">{item.name}</h3>
                  <p className="text-sm text-gray-500 mb-3">{item.fabricType}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3 bg-gray-50 rounded-lg p-1">
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-1 hover:text-gold transition-colors"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="font-bold w-8 text-center">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-1 hover:text-gold transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    <span className="font-bold text-dark">{formatPrice(item.price * item.quantity)}</span>
                  </div>
                </div>
                <button 
                  onClick={() => removeFromCart(item.id)}
                  className="p-2 text-gray-300 hover:text-red-500 transition-colors"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>

          <button 
            onClick={clearCart}
            className="text-sm text-gray-400 hover:text-red-500 font-bold transition-colors"
          >
            Clear Cart
          </button>
        </div>

        {/* Summary / Checkout */}
        <div className="lg:col-span-1">
          <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-lg sticky top-32">
            <h3 className="text-2xl font-bold mb-8">Order Summary</h3>
            
            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-gray-500">
                <span>Subtotal ({totalItems} items)</span>
                <span>{formatPrice(totalPrice)}</span>
              </div>
              <div className="flex justify-between text-gray-500">
                <span>Delivery Fee</span>
                <span className="text-green-600 font-bold">Calculated at checkout</span>
              </div>
              <div className="border-t border-gray-100 pt-4 flex justify-between text-xl font-bold text-dark">
                <span>Total</span>
                <span>{formatPrice(totalPrice)}</span>
              </div>
            </div>

            {!isCheckingOut ? (
              <button 
                onClick={() => setIsCheckingOut(true)}
                className="btn-primary w-full text-lg flex items-center justify-center space-x-2"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            ) : (
              <form onSubmit={handleWhatsAppCheckout} className="space-y-4">
                <h4 className="font-bold text-gold mb-4">Delivery Details</h4>
                <input 
                  required
                  type="text" 
                  placeholder="Full Name"
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full border border-gray-200 rounded-lg py-3 px-4 focus:outline-none focus:border-gold"
                />
                <input 
                  required
                  type="tel" 
                  placeholder="Phone Number"
                  value={formData.phone}
                  onChange={e => setFormData({...formData, phone: e.target.value})}
                  className="w-full border border-gray-200 rounded-lg py-3 px-4 focus:outline-none focus:border-gold"
                />
                <textarea 
                  required
                  placeholder="Delivery Address"
                  value={formData.address}
                  onChange={e => setFormData({...formData, address: e.target.value})}
                  className="w-full border border-gray-200 rounded-lg py-3 px-4 focus:outline-none focus:border-gold"
                ></textarea>
                <div className="grid grid-cols-2 gap-4">
                  <input 
                    required
                    type="text" 
                    placeholder="City"
                    value={formData.city}
                    onChange={e => setFormData({...formData, city: e.target.value})}
                    className="w-full border border-gray-200 rounded-lg py-3 px-4 focus:outline-none focus:border-gold"
                  />
                  <input 
                    required
                    type="text" 
                    placeholder="State"
                    value={formData.state}
                    onChange={e => setFormData({...formData, state: e.target.value})}
                    className="w-full border border-gray-200 rounded-lg py-3 px-4 focus:outline-none focus:border-gold"
                  />
                </div>
                <button 
                  type="submit"
                  className="bg-[#25D366] text-white w-full py-4 rounded-lg font-bold flex items-center justify-center space-x-2 hover:bg-opacity-90 transition-all shadow-lg shadow-green-500/20"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Order via WhatsApp</span>
                </button>
                <button 
                  type="button"
                  onClick={() => setIsCheckingOut(false)}
                  className="w-full text-center text-sm text-gray-400 font-bold"
                >
                  Back to Summary
                </button>
              </form>
            )}

            <div className="mt-8 flex items-center justify-center space-x-2 text-xs text-gray-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Secure checkout powered by WhatsApp</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
