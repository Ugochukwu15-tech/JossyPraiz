import React, { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';
import { WHATSAPP_LINK } from '../constants';

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: "How do I place an order?",
      answer: "You can place an order directly on our website by adding items to your cart and checking out, or you can click the 'Order via WhatsApp' button on any product page to chat with us directly."
    },
    {
      question: "Do you deliver nationwide?",
      answer: "Yes, we deliver to all 36 states in Nigeria. Delivery typically takes 2-3 working days for major cities and 4-5 working days for remote areas."
    },
    {
      question: "What are your payment options?",
      answer: "We accept bank transfers, online payments via card, and in some cases, payment on delivery within specific areas in Lagos."
    },
    {
      question: "Can I buy in bulk or wholesale?",
      answer: "Absolutely! We offer special discounts for bulk buyers, fashion designers, and boutique owners. Please contact us via WhatsApp or our contact form for wholesale pricing."
    },
    {
      question: "What is your return policy?",
      answer: "We take pride in our quality. If you receive a fabric that is damaged or different from what you ordered, please contact us within 48 hours for an exchange or refund."
    },
    {
      question: "Do you have a physical store?",
      answer: "Yes, our main showroom is located in Lagos Island, Lagos. You are welcome to visit us to see and feel our fabrics in person."
    }
  ];

  return (
    <div className="section-padding min-h-screen max-w-4xl mx-auto">
      <div className="text-center mb-16">
        <div className="bg-gold/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
          <HelpCircle className="w-8 h-8 text-gold" />
        </div>
        <h1 className="text-4xl md:text-5xl mb-4">Frequently Asked Questions</h1>
        <p className="text-gray-500">Everything you need to know about shopping with JossyPraiz Textile.</p>
      </div>

      <div className="space-y-4">
        {faqs.map((faq, index) => (
          <div 
            key={index} 
            className="border border-gray-100 rounded-xl overflow-hidden bg-white shadow-sm"
          >
            <button 
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
              className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition-colors"
            >
              <span className="font-bold text-lg text-dark">{faq.question}</span>
              {openIndex === index ? <ChevronUp className="w-5 h-5 text-gold" /> : <ChevronDown className="w-5 h-5 text-gray-400" />}
            </button>
            {openIndex === index && (
              <div className="p-6 pt-0 text-gray-600 leading-relaxed border-t border-gray-50">
                {faq.answer}
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-16 bg-dark text-white p-8 rounded-2xl text-center">
        <h3 className="text-2xl mb-4">Still have questions?</h3>
        <p className="text-gray-400 mb-8">We're here to help. Chat with us on WhatsApp for instant support.</p>
        <a 
          href={WHATSAPP_LINK}
          className="btn-primary inline-block"
        >
          Chat with Us Now
        </a>
      </div>
    </div>
  );
};

export default FAQ;
