import React from 'react';
import { Award, Users, Heart, ShieldCheck, Truck, Globe } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="bg-dark text-white py-24 px-4 text-center">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-5xl md:text-6xl mb-6">Our Story</h1>
          <p className="text-xl text-gray-400 leading-relaxed">
            JossyPraiz Textile was born out of a passion for quality fashion and the rich cultural heritage of Nigerian textiles.
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="section-padding grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div className="relative">
          <img 
            src="https://picsum.photos/seed/about-store/800/1000" 
            alt="Our Store" 
            className="rounded-2xl shadow-2xl"
            referrerPolicy="no-referrer"
          />
          <div className="absolute -bottom-8 -left-8 bg-gold text-white p-8 rounded-2xl hidden md:block">
            <span className="text-4xl font-bold block">10+</span>
            <span className="text-sm uppercase font-bold">Years of Excellence</span>
          </div>
        </div>
        <div>
          <h2 className="text-4xl mb-8">Quality Fabrics for Every Style</h2>
          <div className="space-y-6 text-gray-600 leading-relaxed">
            <p>
              Founded in Lagos, JossyPraiz Textile has grown from a small local shop to a leading nationwide provider of premium clothing materials. We believe that every individual deserves to wear high-quality fabrics that reflect their unique personality and style.
            </p>
            <p>
              We meticulously source our materials from the best manufacturers globally, ensuring that every yard of fabric that leaves our store meets the highest standards of durability, texture, and colorfastness.
            </p>
            <p>
              Our mission is simple: To provide fashion designers, tailors, and individuals with the finest textiles at affordable prices, backed by exceptional customer service and fast delivery.
            </p>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="bg-gray-50 section-padding">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl mb-4">Our Core Values</h2>
          <p className="text-gray-500">The principles that guide everything we do.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-2xl shadow-sm text-center">
            <div className="bg-gold/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Award className="w-8 h-8 text-gold" />
            </div>
            <h4 className="text-xl font-bold mb-4">Quality First</h4>
            <p className="text-gray-500 text-sm">We never compromise on the quality of our fabrics. If it's not premium, it's not JossyPraiz.</p>
          </div>
          <div className="bg-white p-8 rounded-2xl shadow-sm text-center">
            <div className="bg-gold/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Heart className="w-8 h-8 text-gold" />
            </div>
            <h4 className="text-xl font-bold mb-4">Customer Obsessed</h4>
            <p className="text-gray-500 text-sm">Our customers are at the heart of our business. We strive to exceed expectations with every order.</p>
          </div>
          <div className="bg-white p-8 rounded-2xl shadow-sm text-center">
            <div className="bg-gold/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <Globe className="w-8 h-8 text-gold" />
            </div>
            <h4 className="text-xl font-bold mb-4">Integrity</h4>
            <p className="text-gray-500 text-sm">We build trust through transparency, honesty, and reliability in all our dealings.</p>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="section-padding bg-dark text-white text-center">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-12">
          <div>
            <span className="text-4xl md:text-5xl font-bold text-gold block mb-2">5k+</span>
            <span className="text-sm uppercase tracking-widest text-gray-400">Happy Clients</span>
          </div>
          <div>
            <span className="text-4xl md:text-5xl font-bold text-gold block mb-2">500+</span>
            <span className="text-sm uppercase tracking-widest text-gray-400">Fabric Varieties</span>
          </div>
          <div>
            <span className="text-4xl md:text-5xl font-bold text-gold block mb-2">36</span>
            <span className="text-sm uppercase tracking-widest text-gray-400">States Covered</span>
          </div>
          <div>
            <span className="text-4xl md:text-5xl font-bold text-gold block mb-2">100%</span>
            <span className="text-sm uppercase tracking-widest text-gray-400">Satisfaction</span>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
