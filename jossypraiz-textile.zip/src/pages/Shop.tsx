import React, { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Filter, Search, SlidersHorizontal, X, ChevronDown, ChevronUp } from 'lucide-react';
import { PRODUCTS, CATEGORIES } from '../data';
import ProductCard from '../components/ProductCard';
import { formatPrice } from '../lib/utils';

const Shop: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [isFilterMobileOpen, setIsFilterMobileOpen] = useState(false);
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    search: true,
    quick: true,
    categories: true,
    fabric: true,
    colors: true,
    price: true
  });

  const toggleSection = (section: string) => {
    setOpenSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  // Get filters from URL
  const categoryFilter = searchParams.get('category');
  const fabricTypeFilter = searchParams.get('fabricType');
  const colorFilter = searchParams.get('color');
  const isNewArrivals = searchParams.get('new') === 'true';
  const isBestSellers = searchParams.get('best') === 'true';
  const minPrice = searchParams.get('minPrice') ? Number(searchParams.get('minPrice')) : 0;
  const maxPrice = searchParams.get('maxPrice') ? Number(searchParams.get('maxPrice')) : 100000;
  const searchQuery = searchParams.get('q') || '';
  const sortBy = searchParams.get('sort') || 'newest';

  // Extract unique values for filters
  const fabricTypes = useMemo(() => Array.from(new Set(PRODUCTS.map(p => p.fabricType))), []);
  const allColors = useMemo(() => Array.from(new Set(PRODUCTS.flatMap(p => p.colors))), []);

  // Calculate counts for filters
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    PRODUCTS.forEach(p => {
      counts[p.category] = (counts[p.category] || 0) + 1;
    });
    return counts;
  }, []);

  const fabricCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    PRODUCTS.forEach(p => {
      counts[p.fabricType] = (counts[p.fabricType] || 0) + 1;
    });
    return counts;
  }, []);

  const updateFilters = (updates: Record<string, string | null>) => {
    const newParams = new URLSearchParams(searchParams);
    Object.entries(updates).forEach(([key, value]) => {
      if (value === null) {
        newParams.delete(key);
      } else {
        newParams.set(key, value);
      }
    });
    setSearchParams(newParams);
  };

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(product => {
      const matchesCategory = !categoryFilter || product.category === categoryFilter;
      const matchesFabric = !fabricTypeFilter || product.fabricType === fabricTypeFilter;
      const matchesColor = !colorFilter || product.colors.includes(colorFilter);
      const matchesNew = !isNewArrivals || product.isNewArrival;
      const matchesBest = !isBestSellers || product.isBestSeller;
      const matchesPrice = product.price >= minPrice && product.price <= maxPrice;
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           product.fabricType.toLowerCase().includes(searchQuery.toLowerCase());
      
      return matchesCategory && matchesFabric && matchesColor && matchesNew && matchesBest && matchesPrice && matchesSearch;
    });
  }, [categoryFilter, fabricTypeFilter, colorFilter, isNewArrivals, isBestSellers, minPrice, maxPrice, searchQuery]);

  const sortedProducts = useMemo(() => {
    return [...filteredProducts].sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      return 0; // default newest
    });
  }, [filteredProducts, sortBy]);

  const clearAllFilters = () => {
    setSearchParams({});
  };

  const sidebarContent = (
    <>
      {/* Search */}
      <div className="border-b border-gray-100 pb-6">
        <button 
          onClick={() => toggleSection('search')}
          className="w-full flex items-center justify-between font-bold mb-4 group"
        >
          <div className="flex items-center space-x-2">
            <Search className={`w-4 h-4 transition-colors ${searchQuery ? 'text-gold' : 'text-gray-400 group-hover:text-gold'}`} />
            <span>Search</span>
            {searchQuery && <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />}
          </div>
          {openSections.search ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
        </button>
        
        {openSections.search && (
          <div className="relative">
            <input 
              type="text" 
              placeholder="Find a fabric..."
              value={searchQuery}
              onChange={(e) => updateFilters({ q: e.target.value || null })}
              className="w-full border border-gray-200 rounded-md py-2 pl-4 pr-10 focus:outline-none focus:border-gold transition-colors text-sm"
            />
            {searchQuery && (
              <button 
                onClick={() => updateFilters({ q: null })}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-red-500"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        )}
      </div>

      {/* Quick Filters */}
      <div className="border-b border-gray-100 pb-6">
        <button 
          onClick={() => toggleSection('quick')}
          className="w-full flex items-center justify-between font-bold mb-4 group"
        >
          <div className="flex items-center space-x-2">
            <span>Quick Filters</span>
            {(isNewArrivals || isBestSellers) && <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />}
          </div>
          {openSections.quick ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
        </button>

        {openSections.quick && (
          <div className="space-y-3">
            <label className="flex items-center space-x-3 cursor-pointer group">
              <div className="relative flex items-center">
                <input 
                  type="checkbox" 
                  checked={isNewArrivals}
                  onChange={(e) => updateFilters({ new: e.target.checked ? 'true' : null })}
                  className="w-5 h-5 rounded border-gray-300 text-gold focus:ring-gold cursor-pointer transition-all"
                />
              </div>
              <span className={`text-sm transition-colors ${isNewArrivals ? 'text-gold font-bold' : 'text-gray-600 group-hover:text-dark'}`}>
                New Arrivals
              </span>
            </label>
            <label className="flex items-center space-x-3 cursor-pointer group">
              <div className="relative flex items-center">
                <input 
                  type="checkbox" 
                  checked={isBestSellers}
                  onChange={(e) => updateFilters({ best: e.target.checked ? 'true' : null })}
                  className="w-5 h-5 rounded border-gray-300 text-gold focus:ring-gold cursor-pointer transition-all"
                />
              </div>
              <span className={`text-sm transition-colors ${isBestSellers ? 'text-gold font-bold' : 'text-gray-600 group-hover:text-dark'}`}>
                Best Sellers
              </span>
            </label>
          </div>
        )}
      </div>

      {/* Categories */}
      <div className="border-b border-gray-100 pb-6">
        <button 
          onClick={() => toggleSection('categories')}
          className="w-full flex items-center justify-between font-bold mb-4 group"
        >
          <div className="flex items-center space-x-2">
            <Filter className={`w-4 h-4 transition-colors ${categoryFilter ? 'text-gold' : 'text-gray-400 group-hover:text-gold'}`} />
            <span>Categories</span>
            {categoryFilter && <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />}
          </div>
          {openSections.categories ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
        </button>

      {openSections.categories && (
        <div className="space-y-1">
          <button 
            onClick={() => updateFilters({ category: null })}
            className={`flex items-center justify-between w-full text-left px-3 py-2 rounded-md text-sm transition-all ${!categoryFilter ? 'bg-gold text-white font-bold shadow-md transform scale-[1.02]' : 'hover:bg-gray-50 text-gray-600'}`}
          >
            <span>All Materials</span>
            <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${!categoryFilter ? 'bg-white/20' : 'bg-gray-100'}`}>
              {PRODUCTS.length}
            </span>
          </button>
          {CATEGORIES.map(cat => (
            <button 
              key={cat.id}
              onClick={() => updateFilters({ category: cat.id })}
              className={`flex items-center justify-between w-full text-left px-3 py-2 rounded-md text-sm transition-all ${categoryFilter === cat.id ? 'bg-gold text-white font-bold shadow-md transform scale-[1.02]' : 'hover:bg-gray-50 text-gray-600'}`}
            >
              <span>{cat.name}</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${categoryFilter === cat.id ? 'bg-white/20' : 'bg-gray-100'}`}>
                {categoryCounts[cat.id] || 0}
              </span>
            </button>
          ))}
        </div>
      )}
      </div>

      {/* Fabric Type */}
      <div className="border-b border-gray-100 pb-6">
        <button 
          onClick={() => toggleSection('fabric')}
          className="w-full flex items-center justify-between font-bold mb-4 group"
        >
          <div className="flex items-center space-x-2">
            <span>Fabric Type</span>
            {fabricTypeFilter && <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />}
          </div>
          {openSections.fabric ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
        </button>

        {openSections.fabric && (
          <div className="space-y-1">
            <button 
              onClick={() => updateFilters({ fabricType: null })}
              className={`flex items-center justify-between w-full text-left px-3 py-2 rounded-md text-sm transition-all ${!fabricTypeFilter ? 'bg-gold text-white font-bold shadow-md transform scale-[1.02]' : 'hover:bg-gray-50 text-gray-600'}`}
            >
              <span>All Types</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${!fabricTypeFilter ? 'bg-white/20' : 'bg-gray-100'}`}>
                {PRODUCTS.length}
              </span>
            </button>
            {fabricTypes.map(type => (
              <button 
                key={type}
                onClick={() => updateFilters({ fabricType: type })}
                className={`flex items-center justify-between w-full text-left px-3 py-2 rounded-md text-sm transition-all ${fabricTypeFilter === type ? 'bg-gold text-white font-bold shadow-md transform scale-[1.02]' : 'hover:bg-gray-50 text-gray-600'}`}
              >
                <span>{type}</span>
                <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${fabricTypeFilter === type ? 'bg-white/20' : 'bg-gray-100'}`}>
                  {fabricCounts[type] || 0}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Colors */}
      <div className="border-b border-gray-100 pb-6">
        <button 
          onClick={() => toggleSection('colors')}
          className="w-full flex items-center justify-between font-bold mb-4 group"
        >
          <div className="flex items-center space-x-2">
            <span>Colors</span>
            {colorFilter && <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />}
          </div>
          {openSections.colors ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
        </button>

        {openSections.colors && (
          <div className="flex flex-wrap gap-2">
            {allColors.map(color => (
              <button 
                key={color}
                onClick={() => updateFilters({ color: colorFilter === color ? null : color })}
                className={`px-3 py-1 rounded-full text-xs font-bold border transition-all ${colorFilter === color ? 'bg-gold border-gold text-white shadow-sm' : 'bg-white border-gray-200 text-gray-500 hover:border-gold'}`}
              >
                {color}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Price Range */}
      <div className="border-b border-gray-100 pb-6">
        <button 
          onClick={() => toggleSection('price')}
          className="w-full flex items-center justify-between font-bold mb-4 group"
        >
          <div className="flex items-center space-x-2">
            <span>Price Range</span>
            {(minPrice > 0 || maxPrice < 100000) && <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />}
          </div>
          {openSections.price ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
        </button>

        {openSections.price && (
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <input 
                type="number" 
                placeholder="Min"
                value={minPrice || ''}
                onChange={(e) => updateFilters({ minPrice: e.target.value || null })}
                className="w-full border border-gray-200 rounded-md py-1.5 px-3 text-sm focus:outline-none focus:border-gold"
              />
              <span className="text-gray-400">-</span>
              <input 
                type="number" 
                placeholder="Max"
                value={maxPrice === 100000 ? '' : maxPrice}
                onChange={(e) => updateFilters({ maxPrice: e.target.value || null })}
                className="w-full border border-gray-200 rounded-md py-1.5 px-3 text-sm focus:outline-none focus:border-gold"
              />
            </div>
            <div className="text-xs text-gray-400 flex justify-between">
              <span>{formatPrice(minPrice)}</span>
              <span>{formatPrice(maxPrice)}</span>
            </div>
          </div>
        )}
      </div>

      <button 
        onClick={clearAllFilters}
        disabled={!(categoryFilter || fabricTypeFilter || colorFilter || searchQuery || isNewArrivals || isBestSellers || minPrice > 0 || maxPrice < 100000)}
        className={`w-full py-3 text-sm font-bold rounded-xl transition-all border ${
          (categoryFilter || fabricTypeFilter || colorFilter || searchQuery || isNewArrivals || isBestSellers || minPrice > 0 || maxPrice < 100000)
          ? 'border-red-100 text-red-500 hover:bg-red-50 cursor-pointer' 
          : 'border-transparent text-gray-300 cursor-default'
        }`}
      >
        Reset All Filters
      </button>
    </>
  );

  return (
    <div className="section-padding min-h-screen">
      <div className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-4xl md:text-5xl mb-4">Shop All Fabrics</h1>
          <p className="text-gray-500">Browse our extensive collection of premium materials.</p>
        </div>
        
        {/* Mobile Filter Toggle */}
        <button 
          onClick={() => setIsFilterMobileOpen(!isFilterMobileOpen)}
          className="lg:hidden flex items-center space-x-2 bg-dark text-white px-4 py-2 rounded-md font-bold"
        >
          <Filter className="w-4 h-4" />
          <span>Filters</span>
        </button>
      </div>

      {/* Mobile Filter Sidebar Overlay */}
      <AnimatePresence>
        {isFilterMobileOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsFilterMobileOpen(false)}
              className="fixed inset-0 bg-black/50 z-40 lg:hidden backdrop-blur-sm"
            />
            <motion.aside 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 w-[85%] max-w-sm bg-white z-50 lg:hidden overflow-y-auto shadow-2xl"
            >
              <div className="p-6 space-y-8">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-2xl font-bold">Filters</h3>
                  <button 
                    onClick={() => setIsFilterMobileOpen(false)}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
                {sidebarContent}
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <div className="flex flex-col lg:flex-row gap-12">
        {/* Desktop Sidebar Filters */}
        <aside className="hidden lg:block lg:w-64 shrink-0">
          <div className="sticky top-32 space-y-8">
            {sidebarContent}
          </div>
        </aside>

        {/* Product Grid */}
        <main className="flex-1">
          {/* Active Filters Summary */}
          {(categoryFilter || fabricTypeFilter || colorFilter || searchQuery || isNewArrivals || isBestSellers || minPrice > 0 || maxPrice < 100000) && (
            <div className="flex flex-wrap items-center gap-2 mb-6">
              <span className="text-xs font-bold uppercase tracking-wider text-gray-400 mr-2">Active Filters:</span>
              
              {searchQuery && (
                <button 
                  onClick={() => updateFilters({ q: null })}
                  className="flex items-center space-x-1 bg-gray-100 hover:bg-gray-200 px-3 py-1 rounded-full text-xs font-medium transition-colors"
                >
                  <span>Search: {searchQuery}</span>
                  <X className="w-3 h-3" />
                </button>
              )}

              {categoryFilter && (
                <button 
                  onClick={() => updateFilters({ category: null })}
                  className="flex items-center space-x-1 bg-gold/10 text-gold hover:bg-gold/20 px-3 py-1 rounded-full text-xs font-medium transition-colors"
                >
                  <span>Category: {CATEGORIES.find(c => c.id === categoryFilter)?.name}</span>
                  <X className="w-3 h-3" />
                </button>
              )}

              {fabricTypeFilter && (
                <button 
                  onClick={() => updateFilters({ fabricType: null })}
                  className="flex items-center space-x-1 bg-gold/10 text-gold hover:bg-gold/20 px-3 py-1 rounded-full text-xs font-medium transition-colors"
                >
                  <span>Fabric: {fabricTypeFilter}</span>
                  <X className="w-3 h-3" />
                </button>
              )}

              {colorFilter && (
                <button 
                  onClick={() => updateFilters({ color: null })}
                  className="flex items-center space-x-1 bg-gold/10 text-gold hover:bg-gold/20 px-3 py-1 rounded-full text-xs font-medium transition-colors"
                >
                  <span>Color: {colorFilter}</span>
                  <X className="w-3 h-3" />
                </button>
              )}

              {isNewArrivals && (
                <button 
                  onClick={() => updateFilters({ new: null })}
                  className="flex items-center space-x-1 bg-gold/10 text-gold hover:bg-gold/20 px-3 py-1 rounded-full text-xs font-medium transition-colors"
                >
                  <span>New Arrivals</span>
                  <X className="w-3 h-3" />
                </button>
              )}

              {isBestSellers && (
                <button 
                  onClick={() => updateFilters({ best: null })}
                  className="flex items-center space-x-1 bg-gold/10 text-gold hover:bg-gold/20 px-3 py-1 rounded-full text-xs font-medium transition-colors"
                >
                  <span>Best Sellers</span>
                  <X className="w-3 h-3" />
                </button>
              )}

              {(minPrice > 0 || maxPrice < 100000) && (
                <button 
                  onClick={() => updateFilters({ minPrice: null, maxPrice: null })}
                  className="flex items-center space-x-1 bg-gray-100 hover:bg-gray-200 px-3 py-1 rounded-full text-xs font-medium transition-colors"
                >
                  <span>Price: {formatPrice(minPrice)} - {formatPrice(maxPrice)}</span>
                  <X className="w-3 h-3" />
                </button>
              )}

              <button 
                onClick={clearAllFilters}
                className="text-xs font-bold text-red-500 hover:underline ml-2"
              >
                Clear All
              </button>
            </div>
          )}

          <div className="flex flex-col sm:flex-row items-center justify-between mb-8 gap-4">
            <p className="text-sm text-gray-500">
              Showing <span className="font-bold text-dark">{sortedProducts.length}</span> fabrics
              {(categoryFilter || fabricTypeFilter || colorFilter || searchQuery) && (
                <span className="ml-1">matching your criteria</span>
              )}
            </p>
            <div className="flex items-center space-x-2">
              <SlidersHorizontal className="w-4 h-4 text-gray-400" />
              <select 
                value={sortBy}
                onChange={(e) => updateFilters({ sort: e.target.value })}
                className="border-none bg-transparent text-sm font-bold focus:ring-0 cursor-pointer"
              >
                <option value="newest">Newest Arrivals</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
              </select>
            </div>
          </div>

          {sortedProducts.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
              {sortedProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-24 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200">
              <div className="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="w-8 h-8 text-gray-300" />
              </div>
              <h3 className="text-xl font-bold mb-2">No fabrics found</h3>
              <p className="text-gray-500 mb-8 max-w-xs mx-auto">Try adjusting your filters or search query to find what you're looking for.</p>
              <button 
                onClick={clearAllFilters}
                className="btn-primary"
              >
                Clear All Filters
              </button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default Shop;
