import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingCart, MessageCircle, Star, Truck, ShieldCheck, ArrowLeft, Check, Heart, User } from 'lucide-react';
import { PRODUCTS } from '../data';
import { formatPrice } from '../lib/utils';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { motion } from 'motion/react';
import ProductCard from '../components/ProductCard';
import ReviewSystem from '../components/ReviewSystem';
import ErrorBoundary from '../components/ErrorBoundary';
import { useProductReviews } from '../hooks/useProductReviews';
import { WHATSAPP_LINK } from '../constants';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { reviews, averageRating, reviewCount } = useProductReviews(id || '');
  const product = PRODUCTS.find(p => p.id === id);
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const [selectedImage, setSelectedImage] = useState(product?.image || '');
  const [selectedColor, setSelectedColor] = useState(product?.colors[0] || '');

  if (!product) {
    return (
      <div className="section-padding text-center py-32">
        <h2 className="text-2xl mb-4">Product not found</h2>
        <Link to="/shop" className="btn-primary">Back to Shop</Link>
      </div>
    );
  }

  const isWishlisted = isInWishlist(product.id);
  const relatedProducts = PRODUCTS.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);

  const handleWhatsAppOrder = () => {
    const message = `Hello JossyPraiz, I want to order: ${product.name}\nColor: ${selectedColor}\nPrice: ${formatPrice(product.price)}`;
    window.open(`${WHATSAPP_LINK}?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="section-padding">
      <Link to="/shop" className="inline-flex items-center space-x-2 text-gray-500 hover:text-gold mb-8 transition-colors">
        <ArrowLeft className="w-4 h-4" />
        <span className="text-sm font-bold">Back to Shop</span>
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
        {/* Images */}
        <div className="space-y-4">
          <div className="aspect-[3/4] rounded-2xl overflow-hidden bg-gray-100 relative">
            <img 
              src={selectedImage} 
              alt={product.name} 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <button 
              onClick={() => toggleWishlist(product)}
              className={`absolute top-4 right-4 p-3 rounded-full shadow-lg transition-all z-10 ${isWishlisted ? 'bg-gold text-white' : 'bg-white text-gray-400 hover:text-gold'}`}
            >
              <Heart className={`w-6 h-6 ${isWishlisted ? 'fill-current' : ''}`} />
            </button>
          </div>
          <div className="grid grid-cols-4 gap-4">
            {product.images.map((img, idx) => (
              <button 
                key={idx}
                onClick={() => setSelectedImage(img)}
                className={`aspect-square rounded-lg overflow-hidden border-2 transition-all ${selectedImage === img ? 'border-gold' : 'border-transparent'}`}
              >
                <img src={img} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div className="flex flex-col">
          <div className="mb-6">
            <span className="text-gold font-bold uppercase tracking-widest text-xs">{product.category.replace('-', ' ')}</span>
            <h1 className="text-4xl md:text-5xl mt-2 mb-4">{product.name}</h1>
            <div className="flex items-center space-x-4 mb-4">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`w-4 h-4 ${i < Math.round(averageRating) ? 'fill-gold text-gold' : 'text-gray-200'}`} 
                  />
                ))}
              </div>
              <span className="text-sm text-gray-500">({reviewCount} Reviews)</span>
              <span className="text-green-600 font-bold text-sm">In Stock</span>
            </div>
            <p className="text-3xl font-bold text-dark">{formatPrice(product.price)}</p>
          </div>

          <div className="mb-8">
            <h4 className="font-bold mb-3">Fabric Type: <span className="text-gray-500 font-normal">{product.fabricType}</span></h4>
            <p className="text-gray-600 leading-relaxed">{product.description}</p>
          </div>

          <div className="mb-8">
            <h4 className="font-bold mb-4">Select Color/Pattern:</h4>
            <div className="flex flex-wrap gap-3">
              {product.colors.map(color => (
                <button
                  key={color}
                  onClick={() => setSelectedColor(color)}
                  className={`px-4 py-2 rounded-full text-sm font-bold border-2 transition-all ${selectedColor === color ? 'border-gold bg-gold text-white' : 'border-gray-200 hover:border-gold'}`}
                >
                  {color}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
            <button 
              onClick={() => addToCart(product)}
              className="btn-primary flex items-center justify-center space-x-3 text-lg"
            >
              <ShoppingCart className="w-6 h-6" />
              <span>Add to Cart</span>
            </button>
            <button 
              onClick={handleWhatsAppOrder}
              className="bg-[#25D366] text-white px-8 py-4 rounded-md font-bold flex items-center justify-center space-x-3 text-lg hover:bg-opacity-90 transition-all"
            >
              <MessageCircle className="w-6 h-6" />
              <span>Order via WhatsApp</span>
            </button>
          </div>
          
          <button 
            onClick={() => toggleWishlist(product)}
            className={`w-full py-4 rounded-md font-bold flex items-center justify-center space-x-3 text-lg border-2 transition-all mb-8 ${isWishlisted ? 'border-gold bg-gold/5 text-gold' : 'border-gray-200 text-gray-500 hover:border-gold hover:text-gold'}`}
          >
            <Heart className={`w-6 h-6 ${isWishlisted ? 'fill-current' : ''}`} />
            <span>{isWishlisted ? 'Saved to Wishlist' : 'Save for Later'}</span>
          </button>

          <div className="space-y-4 border-t border-gray-100 pt-8">
            <div className="flex items-center space-x-3 text-sm">
              <Truck className="w-5 h-5 text-gold" />
              <span className="font-bold">Fast Delivery:</span>
              <span className="text-gray-500">2-3 working days nationwide</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <ShieldCheck className="w-5 h-5 text-gold" />
              <span className="font-bold">Quality Guaranteed:</span>
              <span className="text-gray-500">Premium materials or your money back</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <Check className="w-5 h-5 text-gold" />
              <span className="font-bold">Bulk Discount:</span>
              <span className="text-gray-500">Available for orders above 10 pieces</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs / More Info */}
      <div className="mb-20">
        <div className="border-b border-gray-200 mb-8">
          <button className="border-b-2 border-gold pb-4 font-bold text-lg">Product Details</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <h4 className="font-bold mb-4">Specifications</h4>
            <ul className="space-y-3 text-sm text-gray-600">
              <li className="flex justify-between border-b border-gray-50 pb-2"><span>Width</span> <span>58/60 inches</span></li>
              <li className="flex justify-between border-b border-gray-50 pb-2"><span>Weight</span> <span>Medium Weight</span></li>
              <li className="flex justify-between border-b border-gray-50 pb-2"><span>Usage</span> <span>Senator, Suits, Native Wear</span></li>
              <li className="flex justify-between border-b border-gray-50 pb-2"><span>Care</span> <span>Hand wash or dry clean recommended</span></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Why buy this fabric?</h4>
            <p className="text-sm text-gray-600 leading-relaxed mb-4">
              This {product.fabricType} is one of our most requested materials. It offers a perfect balance of comfort and durability, making it ideal for the Nigerian climate. Whether you're attending a wedding, a corporate event, or just want to look sharp, this material delivers.
            </p>
            <div className="bg-gray-50 p-4 rounded-lg border-l-4 border-gold">
              <p className="text-xs font-bold text-dark italic">"The texture is amazing. It sews perfectly and doesn't fade after washing." - Customer Review</p>
            </div>
          </div>
        </div>
      </div>

      {/* Product Reviews Section */}
      <section className="mb-20 border-t border-gray-100 pt-20">
        <ErrorBoundary>
          <ReviewSystem productId={product.id} />
        </ErrorBoundary>
      </section>

      {/* Related Products */}
      <section>
        <h2 className="text-3xl mb-8">You May Also Like</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {relatedProducts.map(p => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default ProductDetail;
