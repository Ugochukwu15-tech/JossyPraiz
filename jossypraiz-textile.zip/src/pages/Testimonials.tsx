import React from 'react';
import { TESTIMONIALS } from '../data';
import { Star, Quote } from 'lucide-react';

const Testimonials: React.FC = () => {
  return (
    <div className="section-padding min-h-screen">
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl mb-4">Customer Reviews</h1>
        <p className="text-gray-500 max-w-2xl mx-auto">See why thousands of fashion designers and individuals trust JossyPraiz for their premium fabric needs.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {TESTIMONIALS.map(t => (
          <div key={t.id} className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 relative">
            <Quote className="absolute top-4 right-4 w-10 h-10 text-gold/10" />
            <div className="flex space-x-1 mb-6">
              {[...Array(t.rating)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-gold text-gold" />
              ))}
            </div>
            <p className="text-lg text-dark mb-8 leading-relaxed italic">"{t.content}"</p>
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center text-gold font-bold text-xl">
                {t.name.charAt(0)}
              </div>
              <div>
                <h4 className="font-bold text-dark">{t.name}</h4>
                <p className="text-xs text-gray-500 uppercase tracking-widest">{t.role}</p>
              </div>
            </div>
          </div>
        ))}
        {/* Extra mock testimonials to fill the page */}
        {[1, 2, 3].map(i => (
          <div key={`extra-${i}`} className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 relative">
            <Quote className="absolute top-4 right-4 w-10 h-10 text-gold/10" />
            <div className="flex space-x-1 mb-6">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-gold text-gold" />
              ))}
            </div>
            <p className="text-lg text-dark mb-8 leading-relaxed italic">"The Senator materials I bought are simply top-notch. I've recommended JossyPraiz to all my colleagues in the industry."</p>
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center text-gold font-bold text-xl">
                K
              </div>
              <div>
                <h4 className="font-bold text-dark">Kelechi Obi</h4>
                <p className="text-xs text-gray-500 uppercase tracking-widest">Tailor</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Testimonials;
