import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, ArrowRight, ShoppingBag } from 'lucide-react';
import { useWishlist } from '../context/WishlistContext';
import ProductCard from '../components/ProductCard';
import { motion, AnimatePresence } from 'motion/react';

const Wishlist: React.FC = () => {
  const { wishlist, totalWishlistItems } = useWishlist();

  if (wishlist.length === 0) {
    return (
      <div className="section-padding min-h-[60vh] flex flex-col items-center justify-center text-center">
        <div className="bg-gray-100 p-8 rounded-full mb-6">
          <Heart className="w-16 h-16 text-gray-300" />
        </div>
        <h2 className="text-3xl mb-4">Your wishlist is empty</h2>
        <p className="text-gray-500 mb-8 max-w-md">Save fabrics you love to your wishlist and they'll appear here for easy access later.</p>
        <Link to="/shop" className="btn-primary flex items-center space-x-2">
          <span>Explore Fabrics</span>
          <ArrowRight className="w-5 h-5" />
        </Link>
      </div>
    );
  }

  return (
    <div className="section-padding min-h-screen">
      <div className="mb-12">
        <h1 className="text-4xl md:text-5xl mb-4">Your Wishlist</h1>
        <p className="text-gray-500">You have {totalWishlistItems} items saved for later.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
        <AnimatePresence>
          {wishlist.map(product => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              layout
            >
              <ProductCard product={product} />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <div className="mt-16 bg-gray-50 p-8 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h3 className="text-2xl font-bold mb-2">Ready to order?</h3>
          <p className="text-gray-500">Add your saved items to cart or order directly via WhatsApp.</p>
        </div>
        <Link to="/shop" className="btn-outline flex items-center space-x-2">
          <ShoppingBag className="w-5 h-5" />
          <span>Continue Shopping</span>
        </Link>
      </div>
    </div>
  );
};

export default Wishlist;
