import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ShieldCheck, Truck, Award, Star, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { PRODUCTS, CATEGORIES, TESTIMONIALS } from '../data';
import ProductCard from '../components/ProductCard';

const Home: React.FC = () => {
  const featuredProducts = PRODUCTS.filter(p => p.isBestSeller || p.isNewArrival).slice(0, 4);
  const bestSellers = PRODUCTS.filter(p => p.isBestSeller).slice(0, 4);

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-[80vh] min-h-[600px] flex items-center overflow-hidden bg-dark">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/seed/hero-fabric/1920/1080" 
            alt="Premium Fabrics" 
            className="w-full h-full object-cover opacity-60"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent" />
        </div>

        <div className="relative z-10 section-padding text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl"
          >
            <span className="inline-block bg-gold text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-6">
              Affordable Luxury
            </span>
            <h1 className="text-5xl md:text-7xl font-serif mb-6 leading-tight">
              Quality Fabrics for <span className="text-gold italic">Every Style</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-10 max-w-lg leading-relaxed">
              Discover Nigeria's finest collection of Senator materials, Ankara prints, and premium lace. Elevate your fashion game today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/shop" className="btn-primary text-center flex items-center justify-center space-x-2">
                <span>Shop Collection</span>
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link to="/categories" className="btn-outline text-center border-white text-white hover:bg-white hover:text-dark">
                Browse Categories
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="bg-white py-12 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex items-center space-x-4 p-4 rounded-lg bg-gray-50">
            <div className="bg-gold/10 p-3 rounded-full">
              <Award className="w-8 h-8 text-gold" />
            </div>
            <div>
              <h4 className="font-bold text-dark">Quality Guarantee</h4>
              <p className="text-sm text-gray-500">100% premium fabric materials</p>
            </div>
          </div>
          <div className="flex items-center space-x-4 p-4 rounded-lg bg-gray-50">
            <div className="bg-gold/10 p-3 rounded-full">
              <Truck className="w-8 h-8 text-gold" />
            </div>
            <div>
              <h4 className="font-bold text-dark">Nationwide Delivery</h4>
              <p className="text-sm text-gray-500">Fast shipping across all 36 states</p>
            </div>
          </div>
          <div className="flex items-center space-x-4 p-4 rounded-lg bg-gray-50">
            <div className="bg-gold/10 p-3 rounded-full">
              <ShieldCheck className="w-8 h-8 text-gold" />
            </div>
            <div>
              <h4 className="font-bold text-dark">Secure Payments</h4>
              <p className="text-sm text-gray-500">Safe and reliable order process</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="section-padding">
        <div className="flex items-end justify-between mb-12">
          <div>
            <span className="text-gold font-bold uppercase tracking-widest text-xs">Handpicked for you</span>
            <h2 className="text-3xl md:text-4xl mt-2">Featured Fabrics</h2>
          </div>
          <Link to="/shop" className="text-gold font-bold flex items-center space-x-2 hover:underline">
            <span>View All</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Shop By Category */}
      <section className="bg-gray-50 section-padding">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl mb-4">Shop By Category</h2>
          <p className="text-gray-500 max-w-2xl mx-auto">Explore our wide variety of premium materials tailored for your specific fashion needs.</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-8">
          {CATEGORIES.map(category => (
            <Link 
              key={category.id} 
              to={`/shop?category=${category.id}`}
              className="group relative aspect-square overflow-hidden rounded-xl"
            >
              <img 
                src={category.image} 
                alt={category.name} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-white p-4 text-center">
                <h3 className="text-xl md:text-2xl font-serif mb-2">{category.name}</h3>
                <span className="text-xs font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">Explore Now</span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="section-padding grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div className="relative">
          <img 
            src="https://picsum.photos/seed/fabric-stack/800/1000" 
            alt="Fabric Quality" 
            className="rounded-2xl shadow-2xl"
            referrerPolicy="no-referrer"
          />
          <div className="absolute -bottom-8 -right-8 bg-gold text-white p-8 rounded-2xl hidden md:block max-w-xs">
            <Zap className="w-10 h-10 mb-4" />
            <h4 className="text-xl font-bold mb-2">Fast & Reliable</h4>
            <p className="text-sm opacity-90">We understand the urgency of fashion. We deliver your fabrics on time, every time.</p>
          </div>
        </div>
        <div>
          <span className="text-gold font-bold uppercase tracking-widest text-xs">The JossyPraiz Edge</span>
          <h2 className="text-4xl md:text-5xl mt-4 mb-8 leading-tight">Why Fashion Designers Trust Us</h2>
          <div className="space-y-8">
            <div className="flex items-start space-x-4">
              <div className="bg-dark text-white p-2 rounded-lg mt-1"><Award className="w-5 h-5" /></div>
              <div>
                <h4 className="text-xl font-bold mb-2">Unmatched Quality</h4>
                <p className="text-gray-500">We source only the finest materials that feel good on the skin and last for years.</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="bg-dark text-white p-2 rounded-lg mt-1"><Star className="w-5 h-5" /></div>
              <div>
                <h4 className="text-xl font-bold mb-2">Affordable Pricing</h4>
                <p className="text-gray-500">Luxury doesn't have to be expensive. We offer the best value for your money.</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="bg-dark text-white p-2 rounded-lg mt-1"><Truck className="w-5 h-5" /></div>
              <div>
                <h4 className="text-xl font-bold mb-2">Nationwide Reach</h4>
                <p className="text-gray-500">Whether you're in Lagos, Abuja, or Port Harcourt, we bring the market to your doorstep.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="bg-dark text-white section-padding">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl mb-4">What Our Clients Say</h2>
          <div className="flex justify-center space-x-1 mb-4">
            {[...Array(5)].map((_, i) => <Star key={i} className="w-5 h-5 fill-gold text-gold" />)}
          </div>
          <p className="text-gray-400">Trusted by over 5,000 fashionistas across Nigeria.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map(t => (
            <div key={t.id} className="bg-white/5 p-8 rounded-2xl border border-white/10">
              <p className="text-lg italic mb-6 text-gray-300">"{t.content}"</p>
              <div>
                <h4 className="font-bold text-gold">{t.name}</h4>
                <p className="text-xs text-gray-500 uppercase tracking-widest">{t.role}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Best Sellers */}
      <section className="section-padding">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl mb-4">Best Sellers</h2>
          <p className="text-gray-500">The most loved fabrics by our community this month.</p>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {bestSellers.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Special Offers */}
      <section className="section-padding">
        <div className="bg-gold rounded-3xl p-8 md:p-16 flex flex-col md:flex-row items-center justify-between gap-8 text-white">
          <div className="max-w-xl">
            <h2 className="text-4xl md:text-5xl mb-6">Wholesale & Bulk Deals</h2>
            <p className="text-lg opacity-90 mb-8">Are you a boutique owner or a large-scale tailor? Get exclusive discounts when you buy in bulk. Save more, earn more.</p>
            <Link to="/contact" className="bg-white text-gold px-8 py-4 rounded-md font-bold hover:bg-opacity-90 transition-all inline-block">
              Inquire About Wholesale
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/20 backdrop-blur-md p-6 rounded-2xl text-center">
              <span className="text-3xl font-bold block mb-1">20%</span>
              <span className="text-xs uppercase font-bold">Off Bundles</span>
            </div>
            <div className="bg-white/20 backdrop-blur-md p-6 rounded-2xl text-center">
              <span className="text-3xl font-bold block mb-1">Free</span>
              <span className="text-xs uppercase font-bold">Shipping*</span>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="section-padding text-center bg-gray-50">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl md:text-5xl mb-6">Ready to Style Your Next Masterpiece?</h2>
          <p className="text-lg text-gray-500 mb-10">Don't settle for less. Get the quality you deserve at prices you'll love. Limited stock available on trending patterns.</p>
          <Link to="/shop" className="btn-primary text-xl px-12 py-5 shadow-xl shadow-gold/20">
            Order Now – Limited Stock
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
